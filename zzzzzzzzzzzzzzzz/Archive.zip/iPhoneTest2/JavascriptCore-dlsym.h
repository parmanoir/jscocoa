//
//  JavascriptCore-dlsym.h
//  iPhoneTest
//
//  Created by Patrick Geiller on 11/10/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface JSCocoaSymbolFetcher : NSObject {
}

+ (void)populateJavascriptCoreSymbols;

@end